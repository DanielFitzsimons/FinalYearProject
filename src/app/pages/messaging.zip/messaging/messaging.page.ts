import { Component, OnInit } from '@angular/core';
import { Message, MessageService } from 'src/app/services/message.service';
import { Observable, map } from 'rxjs';
import { Timestamp } from '@angular/fire/firestore';
import { Firestore, collection, collectionData } from '@angular/fire/firestore';
import { AuthenticationService } from 'src/app/services/authentication.service';
@Component({
  selector: 'app-messaging',
  templateUrl: './messaging.page.html',
  styleUrls: ['./messaging.page.scss'],
})
export class MessagingPage implements OnInit {
  conversations!: Conversation[];
  newMessage?: string;
  otherUserName?: string;
  messages!: Observable<Message[]>;

  users$!: Observable<User[]>;


  constructor(private messageService: MessageService,
    private firestore: Firestore,   
    private auth: AuthenticationService
    
    
    ) {}

    ngOnInit() {
      // Make sure you handle the case where getCurrentUserId() could be null
      const currentUserId = this.auth.getCurrentUser() || '';
    
      this.users$ = this.messageService.getUsers().pipe(
        map(users => users.filter(user => user.id !== currentUserId))
      );
    
      //this.messages = this.messageService.getMessages('conversationId');
    }

  async startConversationWithUser(otherUser: User) {
    // Check if a conversation already exists with this user or create a new one
    // For now, let's create a new one for demonstration:
    const participants = [
      { userId: 'yourCurrentUserId', userName: 'Your Name' }, // Replace with actual data
      { userId: otherUser.id, userName: otherUser.name }
    ];
    const newConversationId = await this.messageService.createConversation(participants);

    // Navigate to the new conversation view
    // Implement routing logic based on your app's routing configuration
    // For example:
    // this.router.navigateByUrl(`/conversation/${newConversationId}`);
  }


  openConversation(conversation: Conversation) {
    this.otherUserName = conversation.otherUserName;
    this.messages = this.messageService.getMessages(conversation.id);
  }

  async send(content: string) {
    const message: Message = {
      conversationId: 'conversationId',
      sender: 'userId',
      content: content,
      timestamp: Timestamp.fromDate(new Date()) // This will be converted to Timestamp in the service
    };
    await this.messageService.sendMessage('conversationId', message);
  }
}

export interface Conversation {
  id: string; // Unique identifier for the conversation
  participantIds: string[]; // Array of user IDs of the participants
  lastMessage: string; // The last message sent in this conversation
  lastMessageTimestamp: Date; // Timestamp of the last message
  otherUserName?: string; // Name of the other user in the conversation (for one-on-one chats)
  // Add other relevant properties as needed
}

export interface User {
  id: string;
  name: string;
  // ... other user properties ...
}

