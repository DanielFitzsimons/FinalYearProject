import { Component, OnInit } from '@angular/core';
import { Message, MessageService } from 'src/app/services/message.service';
import { Observable } from 'rxjs';
import { Timestamp } from '@angular/fire/firestore';
@Component({
  selector: 'app-messaging',
  templateUrl: './messaging.page.html',
  styleUrls: ['./messaging.page.scss'],
})
export class MessagingPage implements OnInit {
  conversations!: Conversation[];
  newMessage?: string;
  otherUserName?: string;
  messages!: Observable<Message[]>;

  constructor(private messageService: MessageService) {}

  ngOnInit() {
    this.messages = this.messageService.getMessages('conversationId');
  }

  openConversation(conversation: Conversation) {
    this.otherUserName = conversation.otherUserName;
    this.messages = this.messageService.getMessages(conversation.id);
  }

  async send(content: string) {
    const message: Message = {
      conversationId: 'conversationId',
      sender: 'userId',
      content: content,
      timestamp: Timestamp.fromDate(new Date()) // This will be converted to Timestamp in the service
    };
    await this.messageService.sendMessage('conversationId', message);
  }
}

export interface Conversation {
  id: string; // Unique identifier for the conversation
  participantIds: string[]; // Array of user IDs of the participants
  lastMessage: string; // The last message sent in this conversation
  lastMessageTimestamp: Date; // Timestamp of the last message
  otherUserName?: string; // Name of the other user in the conversation (for one-on-one chats)
  // Add other relevant properties as needed
}
